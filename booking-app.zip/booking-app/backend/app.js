require('dotenv').config();
const express = require('express');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const bodyParser = require('body-parser');
const { openDb } = require('./db');
const endpointSecret = process.env.STRIPE_WEBHOOK_SECRET || '';

const app = express();
app.use(express.json());

// Webhook endpoint requires raw body
app.post('/webhook', bodyParser.raw({type: 'application/json'}), async (req, res) => {
  const sig = req.headers['stripe-signature'];
  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, sig, endpointSecret);
  } catch (err) {
    console.error('Webhook signature verification failed.', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  if (event.type === 'checkout.session.completed') {
    const session = event.data.object;
    const db = await openDb();
    const bookingId = session.client_reference_id || ('bk_' + Math.random().toString(36).slice(2,9));
    const customerId = session.customer;
    const paymentIntent = session.payment_intent;
    const depositPaid = session.amount_total || 0;
    await db.run(
      `INSERT OR REPLACE INTO bookings (id, customer_id, total_amount, deposit_paid, deposit_intent_id, status, balance_due_at)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      bookingId,
      customerId,
      session.metadata?.total_amount || 0,
      depositPaid,
      paymentIntent,
      'deposit_paid',
      session.metadata?.balance_due_at || null
    );
    console.log('Booking stored:', bookingId);
  }

  res.json({received: true});
});

// Create a Checkout session for deposit
app.post('/create-checkout-session', async (req, res) => {
  const { bookingId, customerEmail, totalAmount, depositPercent = 50, balanceDueAt } = req.body;
  if (!bookingId || !customerEmail || !totalAmount) return res.status(400).json({error: 'missing params'});

  const depositAmount = Math.round(totalAmount * (depositPercent/100));

  try {
    const customer = await stripe.customers.create({
      email: customerEmail,
      metadata: { bookingId }
    });

    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      mode: 'payment',
      customer: customer.id,
      client_reference_id: bookingId,
      line_items: [
        {
          price_data: {
            currency: 'gbp',
            product_data: { name: `Booking deposit (${depositPercent}%)` },
            unit_amount: depositAmount
          },
          quantity: 1
        }
      ],
      success_url: `${process.env.FRONTEND_URL || 'http://localhost:3000'}/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.FRONTEND_URL || 'http://localhost:3000'}/cancel`,
      billing_address_collection: 'auto',
      payment_intent_data: {
        setup_future_usage: 'off_session'
      },
      metadata: {
        total_amount: totalAmount,
        balance_due_at: balanceDueAt || null
      }
    });

    res.json({ id: session.id });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

app.get('/session/:id', async (req, res) => {
  try {
    const session = await stripe.checkout.sessions.retrieve(req.params.id);
    res.json(session);
  } catch (err) {
    res.status(500).json({error: err.message});
  }
});

const PORT = process.env.PORT || 4242;
app.listen(PORT, async () => {
  const db = await openDb();
  await db.exec(`
    CREATE TABLE IF NOT EXISTS bookings (
      id TEXT PRIMARY KEY,
      customer_id TEXT,
      total_amount INTEGER,
      deposit_paid INTEGER,
      deposit_intent_id TEXT,
      status TEXT,
      balance_due_at TEXT,
      balance_paid INTEGER DEFAULT 0,
      balance_payment_intent TEXT
    );
  `);
  console.log('Server running on port', PORT);
});
