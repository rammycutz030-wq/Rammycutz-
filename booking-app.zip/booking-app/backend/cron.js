require('dotenv').config();
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const { openDb } = require('./db');
const cron = require('node-cron');

async function chargeDueBalances() {
  const db = await openDb();
  const rows = await db.all(`SELECT * FROM bookings WHERE status='deposit_paid' AND balance_paid=0 AND balance_due_at IS NOT NULL`);
  const today = new Date().toISOString().slice(0,10);
  for (const r of rows) {
    if (r.balance_due_at <= today) {
      console.log('Attempting charge for booking', r.id);
      try {
        const customer = await stripe.customers.retrieve(r.customer_id, { expand: ['invoice_settings.default_payment_method'] });
        const pm = customer.invoice_settings?.default_payment_method;
        if (!pm) {
          console.warn('No saved PM for customer', r.customer_id);
          continue;
        }
        const balanceAmount = (r.total_amount || 0) - (r.deposit_paid || 0);
        if (balanceAmount <= 0) {
          await db.run('UPDATE bookings SET balance_paid=1 WHERE id=?', r.id);
          continue;
        }
        const paymentIntent = await stripe.paymentIntents.create({
          amount: balanceAmount,
          currency: 'gbp',
          customer: r.customer_id,
          payment_method: pm.id,
          off_session: true,
          confirm: true,
          description: `Balance payment for booking ${r.id}`
        });
        await db.run('UPDATE bookings SET balance_paid=1, balance_payment_intent=? WHERE id=?', paymentIntent.id, r.id);
        console.log('Successfully charged balance for booking', r.id);
      } catch (err) {
        console.error('Failed to charge balance for', r.id, err.message);
      }
    }
  }
}

// run daily at 02:00
cron.schedule('0 2 * * *', () => {
  console.log('Running daily balance charge job...');
  chargeDueBalances();
});

// run once at startup
chargeDueBalances().catch(console.error);
