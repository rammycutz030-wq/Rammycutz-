# Booking App (Prototype)

This is a minimal booking app prototype:
- Frontend (React) — booking form that creates a Stripe Checkout session for a deposit payment.
- Backend (Node/Express) — creates Checkout sessions, receives Stripe webhook, saves bookings to SQLite.
- Cron job to charge balances when due (uses saved payment method for off-session charges).

**Quick start (local)**

1. Backend:
   - cd backend
   - copy .env.example to .env and fill STRIPE keys
   - npm install
   - npm start
   - (in another terminal) npm run cron

2. Frontend:
   - cd frontend
   - copy .env.example to .env and set REACT_APP_API_URL & REACT_APP_STRIPE_PUBLISHABLE_KEY
   - npm install
   - npm start

3. Webhooks:
   - Use ngrok to expose backend: `ngrok http 4242`
   - In Stripe Dashboard, add webhook `https://<your-ngrok>/webhook` and subscribe to `checkout.session.completed` (and others you need).
   - Copy webhook secret to backend .env

Notes:
- This is a starting prototype. Please review security, PCI scope, retries, email notifications, and production deployment before going live.
