import React, { useState } from 'react';

export default function BookingForm() {
  const [email, setEmail] = useState('');
  const [total, setTotal] = useState(10000); // in pence
  const [depositPercent, setDepositPercent] = useState(50);
  const [msg, setMsg] = useState('');

  async function handleSubmit(e) {
    e.preventDefault();
    setMsg('Creating checkout...');
    const bookingId = 'bk_' + Math.random().toString(36).slice(2,10);
    const res = await fetch(`${process.env.REACT_APP_API_URL || 'http://localhost:4242'}/create-checkout-session`, {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        bookingId,
        customerEmail: email,
        totalAmount: total,
        depositPercent,
        balanceDueAt: new Date(Date.now() + 7*24*3600*1000).toISOString().slice(0,10)
      })
    });
    const data = await res.json();
    if (data.error) {
      setMsg('Error: ' + data.error);
      return;
    }
    const stripe = window.Stripe(process.env.REACT_APP_STRIPE_PUBLISHABLE_KEY || 'pk_test_xxx');
    await stripe.redirectToCheckout({ sessionId: data.id });
  }

  return (
    <form onSubmit={handleSubmit}>
      <h2>Book a service</h2>
      <div>
        <label>Email: <input type="email" value={email} onChange={e=>setEmail(e.target.value)} required/></label>
      </div>
      <div>
        <label>Total amount (pence): <input value={total} onChange={e=>setTotal(parseInt(e.target.value||0))} /></label>
      </div>
      <div>
        <label>Deposit %: <input type="number" value={depositPercent} onChange={e=>setDepositPercent(parseInt(e.target.value))} /></label>
      </div>
      <button type="submit">Pay deposit & book</button>
      <div>{msg}</div>
    </form>
  );
}
